package com.tcell.upsc;	
	/*
	 * To change this license header, choose License Headers in Project Properties.
	 * To change this template file, choose Tools | Templates
	 * and open the template in the editor.
	 */
	

	import java.math.BigInteger;
	import java.security.InvalidKeyException;
	import java.security.KeyFactory;
	import java.security.MessageDigest;
	import java.security.NoSuchAlgorithmException;
	import java.security.NoSuchProviderException;
	import java.security.SecureRandom;
	import java.security.interfaces.RSAPublicKey;
	import java.security.spec.InvalidKeySpecException;
	import java.security.spec.RSAPublicKeySpec;
	import javax.crypto.BadPaddingException;
	import javax.crypto.Cipher;
	import javax.crypto.IllegalBlockSizeException;
	import javax.crypto.NoSuchPaddingException;

	public class UtilsHandler {

	    public String getSecureRandomlyGeneratedV() throws NoSuchAlgorithmException, NoSuchProviderException {

	        char[] available_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-.".toCharArray();
	        StringBuilder V = new StringBuilder();
	        SecureRandom secureRandomGenerator = SecureRandom.getInstance("SHA1PRNG", "SUN");
	        int[] v_int = new int[10];
	        for(int i =0; i<v_int.length;i++)
	        {
	           v_int[i] = secureRandomGenerator.nextInt(64);
	           char c1 = available_chars[v_int[i]];
	           V.append(c1);
	        }
	        return V.toString();
	    }

	 
	    public String bytesToString(byte[] bytes) {
	        StringBuffer sb = new StringBuffer();
	        for (byte b : bytes) {
	            sb.append(String.format("%02x ", b & 0xFF));
	        }
	        return sb.toString();
	    }

	    public byte[] getBytes(String s) {
	        int len = s.length();
	        byte[] result = new byte[len / 2];
	        for (int i = 0; i < len; i += 2) {
	            result[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character
	                    .digit(s.charAt(i + 1), 16));
	        }
	        return result;

	    }

	    public String convertArray(char[] str) {
	        StringBuffer ostr = new StringBuffer();
	        String hex = "";
	        for (int i = 0; i < str.length; i++) {
	            hex = Integer.toHexString(str[i] & 0xFFFF);
	            ostr.append(hex.toUpperCase());

	        }
	        return (new String(ostr));
	    }

	    public String decimal2hex(int d) {
	        String digits = "0123456789ABCDEF";
	        if (d == 0) {
	            return "0";
	        }
	        String hex = "";
	        while (d > 0) {
	            int digit = d % 16; // rightmost digit
	            hex = digits.charAt(digit) + hex; // string concatenation
	            d = d / 16;
	        }
	        return hex;
	    }

	    public int hex2decimal(String s) {
	        String digits = "0123456789ABCDEF";
	        s = s.toUpperCase();
	        int val = 0;
	        for (int i = 0; i < s.length(); i++) {
	            char c = s.charAt(i);
	            int d = digits.indexOf(c);
	            val = 16 * val + d;
	        }
	        return val;
	    }

	    public String getCharacters(String HEX) {

	        int len = HEX.length();
	        int[] dec = new int[len / 2];
	        StringBuilder sb = new StringBuilder();
	        String tmp = "";
	        int index = 0;
	        for (int k = 0; k < len; k += 2) {
	            tmp = HEX.substring(k, k + 2);
	            int rs = hex2decimal(tmp);
	            dec[index] = rs;
	            index++;
	        }

	        for (int i = 0; i < dec.length; i++) {
	            char f;
	            f = (char) dec[i];
	            sb.append(f);
	        }

	        return sb.toString();

	    }

	    public byte[] getByteCharString(String s) {
	        char[] tempChar = new char[s.length()];
	        for (int w = 0; w < s.length(); w++) {
	            tempChar[w] = s.charAt(w);
	        }
	        String tempCharString = convertArray(tempChar);
	        byte[] tempArray = getBytes(tempCharString);
	        return tempArray;
	    }
	    
	    String hexEncode(byte[] val) { 
	        StringBuilder buff = new StringBuilder(2 * val.length); 
	        for (byte b : val) { 
	            buff.append("0123456789ABCDEF".charAt((b >> 4) & 0xF)); 
	            buff.append("0123456789ABCDEF".charAt(b & 0xF)); 
	        } 
	        return buff.toString(); 
	    } 

	    byte[] calculateHash1(byte[] source) throws NoSuchAlgorithmException
	    {
	        byte[] id = new byte[12];
	        System.arraycopy(source, 0, id, 0, id.length);
	        byte[] v = new byte[10];
	        System.arraycopy(source, id.length, v, 0, v.length);

	        byte[] g = new byte[128];
	        System.arraycopy(source, id.length + v.length, g, 0, g.length);

	        
	       int len = 8 + id.length + v.length + g.length;
	        byte[] hash1Input=new byte[len];
	        for(int i =0; i<hash1Input.length ; i++)
	            hash1Input[i] = (byte) 0x00;
	        hash1Input[3]=(byte) 0x01;
	        
	        hash1Input[7]=(byte) (id.length+v.length+g.length);
	        
	        System.arraycopy(id, (short) 0, hash1Input, (short) 8 , (short) id.length);
	        System.arraycopy(v, (short) 0, hash1Input, (short) (8 +id.length), (short) v.length);
	        System.arraycopy(g, (short) 0, hash1Input, (short) (8 +id.length+v.length), (short) g.length);
	        MessageDigest md = MessageDigest.getInstance("SHA-1");
	        byte[] res = md.digest(hash1Input);
	        byte[] result=new byte[res.length-4]; 
	        System.arraycopy(res,  4, result,  0 , res.length-4);
	        
	        return result;
	    }
	    
	    
	    byte[] calculateHash2(byte[] source) throws NoSuchAlgorithmException
	    {  
	       int len = 8 + source.length;  
	        byte[] hash2Input=new byte[len];
	        for(int i =0; i<hash2Input.length ; i++)
	            hash2Input[i] = (byte) 0x00;
	        hash2Input[3]=(byte) 0x02;
	        hash2Input[6]=(byte)((short) (source.length) / 256);
	        hash2Input[7]=(byte)((short) (source.length) % 256);
	        System.arraycopy(source, (short) 0, hash2Input, (short) (8 ), (short) source.length);
	        MessageDigest md = MessageDigest.getInstance("SHA-1");
	        byte[] res = md.digest(hash2Input);
	        byte[] result = new byte[res.length-4];
	        System.arraycopy(res,  4, result,  0 , res.length-4);
	        return result;
	    }
	    
	    byte[] calculateHash3(byte[] source) throws NoSuchAlgorithmException
	    {   
	       int len = 8 + source.length;
	        byte[] hash3Input=new byte[len];
	        for(int i =0; i<hash3Input.length ; i++)
	            hash3Input[i] = (byte) 0x00;
	        hash3Input[3]=(byte) 0x03;
	        hash3Input[7]=(byte) (source.length);
	        System.arraycopy(source, (short) 0, hash3Input, (short) (8 ), (short) source.length);
	        MessageDigest md = MessageDigest.getInstance("SHA-1");
	        byte[] res = md.digest(hash3Input);
	        return res;
	    }
	    
	    public byte[] calculateExponent(byte[] base,byte [] exponent) throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchProviderException
	    {
	       KeyFactory gen=KeyFactory.getInstance("RSA"); 
	       String p = this.hexEncode(this.receiveP()); 
	       final BigInteger n= new BigInteger(p,16);   
	      final BigInteger e=new BigInteger(this.hexEncode(exponent),16);
	      RSAPublicKey key=(RSAPublicKey)gen.generatePublic(new RSAPublicKeySpec(n,e));
	      Cipher cipher = Cipher.getInstance("RSA/ECB/NoPadding");
	      cipher.init(Cipher.ENCRYPT_MODE, key);
	      byte[] rs = cipher.doFinal(base);
	      return rs;
	    }
	   
	    public byte[] calculategab(byte[] input) throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchProviderException
	    {
	       KeyFactory gen=KeyFactory.getInstance("RSA"); 
	       String p = this.hexEncode(this.receiveP()); 
	       final BigInteger n= new BigInteger(p,16);  
	       String b = this.hexEncode(this.receiveB()); 
	       final BigInteger e=new BigInteger(b,16);   
	      RSAPublicKey key=(RSAPublicKey)gen.generatePublic(new RSAPublicKeySpec(n,e));  
	      Cipher cipher = Cipher.getInstance("RSA/ECB/NoPadding");
	      cipher.init(Cipher.ENCRYPT_MODE, key);
	      byte[] rs = cipher.doFinal(input);

	      return rs;
	    }
	   
	    public byte[] receiveP()
	    {
	        byte[] p = {(byte)0xFF,(byte) 0xFF,(byte) 0xFF,(byte) 0xFF,(byte) 0xFF,(byte) 0xFF,(byte) 0xFF,
	            (byte) 0xFF,(byte) 0xC9,(byte) 0x0F,(byte) 0xDA,(byte) 0xA2,(byte) 0x21,(byte) 0x68,(byte) 0xC2,
	            (byte) 0x34,(byte) 0xC4,(byte) 0xC6,(byte) 0x62,(byte) 0x8B,(byte) 0x80,(byte) 0xDC,(byte) 0x1C,
	            (byte) 0xD1,(byte) 0x29,(byte) 0x02,(byte) 0x4E,(byte) 0x08,(byte) 0x8A,(byte) 0x67,(byte) 0xCC,
	            (byte) 0x74,(byte) 0x02,(byte) 0x0B,(byte) 0xBE,(byte) 0xA6,(byte) 0x3B,(byte) 0x13,(byte) 0x9B,
	            (byte) 0x22,(byte) 0x51,(byte) 0x4A,(byte) 0x08,(byte) 0x79,(byte) 0x8E,(byte) 0x34,(byte) 0x04,
	            (byte) 0xDD,(byte) 0xEF,(byte) 0x95,(byte) 0x19,(byte) 0xB3,(byte) 0xCD,(byte) 0x3A,(byte) 0x43,
	            (byte) 0x1B,(byte) 0x30,(byte) 0x2B,(byte) 0x0A,(byte) 0x6D,(byte) 0xF2,(byte) 0x5F,(byte) 0x14,
	            (byte) 0x37,(byte) 0x4F,(byte) 0xE1,(byte) 0x35,(byte) 0x6D,(byte) 0x6D,(byte) 0x51,(byte) 0xC2,
	            (byte) 0x45,(byte) 0xE4,(byte) 0x85,(byte) 0xB5,(byte) 0x76,(byte) 0x62,(byte) 0x5E,(byte) 0x7E,
	            (byte) 0xC6,(byte) 0xF4,(byte) 0x4C,(byte) 0x42,(byte) 0xE9,(byte) 0xA6,(byte) 0x37,(byte) 0xED,
	            (byte) 0x6B,(byte) 0x0B,(byte) 0xFF,(byte) 0x5C,(byte) 0xB6,(byte) 0xF4,(byte) 0x06,(byte) 0xB7,
	            (byte) 0xED,(byte) 0xEE,(byte) 0x38,(byte) 0x6B,(byte) 0xFB,(byte) 0x5A,(byte) 0x89,(byte) 0x9F,
	            (byte) 0xA5,(byte) 0xAE,(byte) 0x9F,(byte) 0x24,(byte) 0x11,(byte) 0x7C,(byte) 0x4B,(byte) 0x1F,
	            (byte) 0xE6,(byte) 0x49,(byte) 0x28,(byte) 0x66,(byte) 0x51,(byte) 0xEC,(byte) 0xE6,(byte) 0x53,
	            (byte) 0x81,(byte) 0xFF,(byte) 0xFF,
	            (byte) 0xFF,(byte) 0xFF,(byte) 0xFF,(byte) 0xFF,(byte) 0xFF,(byte) 0xFF};
	        
	        return p;
	    }
	    
	    public byte[] receiveG()
	    {
	        byte[] temp = {(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
	    			(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
	    			(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
	    			(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, 
	    			(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
	    			(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, 
	    			(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
	    			(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, 
	    			(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
	    			(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, 
	    			(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
	    			(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, 
	    			(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
	    			(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, 
	    			(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
	    			(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x0c };
	        
	        return temp;
	    }
	    public byte[] receiveA()
	    {
	        byte[] temp = { 
	        		(byte) 0XE7,(byte) 0X3B,(byte) 0X2F,(byte) 0X40,(byte) 0X28,(byte) 0X2B,(byte) 0X44,(byte) 0X7D,(byte) 0X5E,(byte) 0X75,(byte) 0X2B,(byte) 0X07,(byte) 0X4B,(byte) 0XF4,(byte) 0XE3,(byte) 0X75,(byte) 0XE0,(byte) 0X18,(byte) 0X42,(byte) 0X97,(byte) 0XBE,(byte) 0XA6,(byte) 0XE2,(byte) 0X9D,(byte) 0X3E,(byte) 0X76,(byte) 0X79,(byte) 0XA6,(byte) 0X44,(byte) 0XEE,(byte) 0X17,(byte) 0X03,(byte) 0X71,(byte) 0X22,(byte) 0XC1,(byte) 0X96,(byte) 0X6D,(byte) 0X89,(byte) 0X7D,(byte) 0XBB,(byte) 0X86,(byte) 0X48,(byte) 0X2B,(byte) 0X9B,(byte) 0X8A,(byte) 0X28,(byte) 0X23,(byte) 0X4D};
	        return temp;
	    }
	    
	    public byte[] receiveB() throws NoSuchAlgorithmException, NoSuchProviderException
	    {
	        byte[] b = {
	        		(byte) 0X2B,(byte) 0X6B,(byte) 0X69,(byte) 0X1F,(byte) 0XDB,(byte) 0X2A,(byte) 0XB6,(byte) 0XBB,(byte) 0X29,(byte) 0X88,(byte) 0X38,(byte) 0XF7,(byte) 0XA9,(byte) 0X57,(byte) 0X0D,(byte) 0X94,(byte) 0X1E,(byte) 0X2B,(byte) 0X31,(byte) 0X82,(byte) 0XC3,(byte) 0X6D,(byte) 0X43,(byte) 0XFD,(byte) 0XAE,(byte) 0XBF,(byte) 0X12,(byte) 0X5F,(byte) 0X9C,(byte) 0XDE,(byte) 0X4F,(byte) 0XE2,(byte) 0X62,(byte) 0XB7,(byte) 0X7D,(byte) 0XA5,(byte) 0X38,(byte) 0X09,(byte) 0X47,(byte) 0XEA,(byte) 0X7E,(byte) 0X7B,(byte) 0XE9,(byte) 0X7F,(byte) 0XD6,(byte) 0X13,(byte) 0X0C,(byte) 0XBA};  
	        return b;
	    }
	    
	    public byte[] receiveIDSim()
	    {
	        byte [] idSIM = {(byte)0x31,(byte) 0x50,(byte) 0x92,(byte) 0x00,(byte) 0x00,(byte) 0x70,
	        (byte) 0xF8,(byte) 0x15,(byte) 0x32,(byte) 0x62,(byte) 0x23,(byte) 0x71};
	        return idSIM;
	    }
	    
	}


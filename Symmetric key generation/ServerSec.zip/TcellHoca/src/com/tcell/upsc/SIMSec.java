package com.tcell.upsc;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.spec.InvalidKeySpecException;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class SIMSec {

    public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchProviderException {
       
        UtilsHandler uh = new UtilsHandler();
        
        String v = "JGm8.uMhNl";
        byte[] V = uh.getByteCharString(v);
        byte[] gaModp = uh.calculateExponent(uh.receiveG(),uh.receiveA());
        System.out.println("ga modp " + uh.bytesToString(gaModp));
        byte[] idSIM = uh.receiveIDSim();
        int len = idSIM.length + V.length + gaModp.length;
        byte[] h1Input = new byte[len]; 
        System.arraycopy(idSIM, 0, h1Input, 0, idSIM.length);
        System.arraycopy(V, 0, h1Input, idSIM.length, V.length);
        System.arraycopy(gaModp, 0, h1Input, idSIM.length + V.length, gaModp.length);
        byte[] h1Result = uh.calculateHash1(h1Input);
        System.out.println("H1 Input " + uh.bytesToString(h1Input));
        System.out.println("H1 result " + uh.bytesToString(h1Result));
        byte[] gbModp = uh.calculateExponent(uh.receiveG(),uh.receiveB());
        System.out.println("gb modp " +  uh.bytesToString(gbModp));
        byte[] gabModp = uh.calculateExponent(gaModp,uh.receiveB());
        System.out.println("gab modp " +  uh.bytesToString(gabModp));
        
        // Hash 2 computation
        int len2 = idSIM.length + V.length + gaModp.length + gbModp.length + gabModp.length;
        byte[] h2Input = new byte[len2];
        
        System.arraycopy(idSIM, 0, h2Input, 0, idSIM.length);
        System.arraycopy(V, 0, h2Input, idSIM.length, V.length);
        System.arraycopy(gaModp, 0, h2Input, idSIM.length + V.length, gaModp.length);
        System.arraycopy(gbModp, 0, h2Input, idSIM.length + V.length + gaModp.length, gbModp.length);
        System.arraycopy(gabModp, 0, h2Input, idSIM.length + V.length + gaModp.length + gbModp.length, gabModp.length);
        System.out.println("Hash 2 input " + uh.bytesToString(h2Input));
        byte[] h2 = uh.calculateHash2(h2Input);
        System.out.println("Hash 2 output " + uh.bytesToString(h2));

         // Hash 3 computation
        
        int len3 = idSIM.length + V.length + gabModp.length;
        byte[] h3Input = new byte[len3];
        
        System.arraycopy(idSIM, 0, h3Input, 0, idSIM.length);
        System.arraycopy(V, 0, h3Input, idSIM.length, V.length);
        System.arraycopy(gabModp, 0, h3Input, idSIM.length + V.length , gabModp.length);
        System.out.println("Hash 3 input " + uh.bytesToString(h3Input));
        byte[] h3 =uh.calculateHash3(h3Input);
        System.out.println("Hash 3 output " + uh.bytesToString(h3));
        
        
        byte[] finalKey = new byte[24];
        System.arraycopy(h3, 0, finalKey, 0, 7);
        System.arraycopy(V, 1, finalKey, 7, 1);
        System.arraycopy(h3, 7, finalKey, 8, 7);
        System.arraycopy(V, 2, finalKey, 15, 1);
        System.arraycopy(h3, 14, finalKey, 16, 6);
        System.arraycopy(V, 0, finalKey, 22, 1);
        System.arraycopy(V, 3, finalKey, 23, 1);
       System.out.println("Final Key " + uh.bytesToString(finalKey));
       
       //send finalKey to OTA

        
    }
    
}

